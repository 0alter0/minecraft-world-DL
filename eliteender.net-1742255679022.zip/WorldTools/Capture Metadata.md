# eliteender.net (Multiplayer) World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Mon, 17 Mar 2025 19:54:39 -0400` (Timestamp: `1742255679022`)
- **Captured By**: `null`

## Singleplayer Capture
- **Source World Name**: `null`
- **Version**: `null`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
