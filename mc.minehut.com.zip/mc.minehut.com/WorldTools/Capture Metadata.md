# mc.minehut.com World Save - Snapshot Details
![Server Icon](../icon.png)

- **Time**: `Mon, 17 Mar 2025 19:51:46 -0400` (Timestamp: `1742255506156`)
- **Captured By**: `Lil_Skittle666`

## Server
- **List Entry Name**: `Minehut`
- **IP**: `mc.minehut.com`
- **Capacity**: `5549/1825`
- **Brand**: `Minehut/Paper (Velocity)`
- **MOTD**: `  Minehut.com The Server Hosting Network                   1825 servers running.`
- **Version**: `Velocity 1.7.2-1.21.4`
- **Protocol Version**: `769`
- **Server Type**: `OTHER`

## Connection
- **Host Name**: `172.65.184.122`
- **Port**: `25565`
- **Session ID**: `dd73556d-d310-4b27-8e85-1dafcf83a07d`

This file was created by [WorldTools 1.2.8](https://github.com/Avanatiker/WorldTools/)
